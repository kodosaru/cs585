//
//  main.cpp
//  Lab2
//
//  Created by Donald Johnson on 1/28/14.
//  Copyright (c) 2014 Donald Johnson. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[])
{

    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

